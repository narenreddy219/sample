# ReconStreamPipeline

Scala 2.12 / Java 17 / Maven starter for consuming JSON events directly from
an on-premises Kafka cluster with Spark Structured Streaming and committing
them to Apache Iceberg v2 tables.

Amazon MSK is not used. Trino is intentionally outside this first delivery.

## Architecture

```text
Local:
Redpanda -> Spark Structured Streaming -> Iceberg -> MinIO

EKS:
On-prem Kafka -> VPN/Direct Connect -> Spark on EKS -> Iceberg on S3
                                                     -> Glue Data Catalog
```

Component boundaries:

- Kafka is the source broker.
- Spark Structured Streaming is the Kafka consumer and processor.
- Iceberg is the transactional table format.
- MinIO is local S3-compatible object storage only.
- Amazon S3 is the EKS object store.
- Glue is the production Iceberg catalog.
- Spark SQL validates the local tables.

## Source layout

```text
src/main/scala/com/citi/olympus/gru/liftandshiftpipeline/
  config/       typed configuration and Spark catalog creation
  kafka/        broker health check and streaming reader
  schema/       bounded schema discovery and compatibility validation
  parser/       JSON parsing, flattening, lineage, and error classification
  iceberg/      table creation/evolution, stream commits, and maintenance
  listener/     structured-stream progress logging
  LifecycleEventsApp.scala
  liftandshiftpipelineApp.scala
```

`liftandshiftpipelineApp` is the executable main class. It delegates to
`LifecycleEventsApp`, which performs this sequence:

```text
configuration -> Spark -> Kafka health -> frozen payload schema -> Kafka stream
-> JSON parser -> Iceberg writer -> checkpoint/recovery
```

## Payload schema behavior

The default local mode uses a temporary Kafka consumer to read a bounded sample.
It does not commit offsets. Spark infers a schema from those JSON strings, and
that schema is frozen for the lifetime of the streaming run. The real streaming
reader then starts from its configured offsets.

For controlled environments, set `schemaInference.mode=schema-resource` and
provide a Spark `StructType` JSON resource. The application never reinfers a
different schema for every micro-batch.

Nested structs can be flattened. Arrays remain arrays. Name collisions stop the
application rather than overwrite data. Compatible new nullable columns are
added to Iceberg; incompatible changes stop the batch and allow the EKS restart
policy to take effect.

Each target row retains:

```text
kafka_key, kafka_topic, kafka_partition, kafka_offset,
kafka_timestamp, ingestion_timestamp
```

Malformed JSON is written to the configured Iceberg DLQ table with the raw
payload and Kafka lineage.

## Prerequisites

- JDK 17
- Maven 3.9+
- Spark 3.5.x (`spark-submit` and `spark-sql` on `PATH`)
- Docker with Docker Compose

Verify:

```bash
java -version
mvn -version
spark-submit --version
docker compose version
```

## Build

```bash
chmod +x scripts/*.sh
./scripts/build.sh
```

The build runs tests and creates:

```text
target/ReconStreamPipeline.jar
target/dependency/
```

## Run locally

Terminal 1:

```bash
./scripts/start-local.sh
```

The first run copies `.env.local.example` to `.env`. The included credentials
and `localhost` endpoints are strictly for local development.

Terminal 2, within the configured schema-sampling window:

```bash
./scripts/publish-sample.sh
```

Terminal 3, after at least one micro-batch commits:

```bash
./scripts/query-local.sh
```

MinIO console: `http://localhost:9001`.

Stop containers without deleting local Iceberg data:

```bash
./scripts/stop-local.sh
```

To intentionally remove the local volume:

```bash
docker compose -f docker-compose.local.yml down -v
```

## EKS configuration

Production settings come from `source_connector_dev.conf` or
`source_connector_uat.conf`, environment variables, a ConfigMap, and a Secret.
The production configuration:

- connects directly to every on-prem Kafka broker returned in
  `advertised.listeners`;
- uses Amazon S3 for the Iceberg warehouse and checkpoint;
- uses AWS Glue Catalog;
- receives AWS permissions from EKS Pod Identity or IRSA;
- does not configure a MinIO endpoint or static AWS keys.

Required network paths include corporate DNS, every advertised Kafka broker,
S3, Glue, and KMS when customer-managed encryption is used.

Required AWS access is scoped to the approved warehouse/checkpoint prefixes,
Glue database/tables, and the applicable KMS key. Do not grant broad account
access.

## Build the image

First run `./scripts/build.sh`, then:

```bash
docker build \
  --build-arg SPARK_BASE_IMAGE=<approved-java17-spark35-image> \
  -t <approved-ecr-image-uri>:<immutable-tag> .
```

The Docker build verifies that the supplied Spark base image uses Java 17.
Push the immutable image using the organization's approved ECR process.

## Deploy to EKS

Resolve every `TODO(RECON-CONFIG)` and every `REPLACE_WITH...` marker first.
Do not apply `secret.example.yaml` with real secrets committed to source control.

```bash
kubectl apply -f deployment/service-account.yaml
kubectl apply -f deployment/configmap.yaml
kubectl apply -f deployment/secret.example.yaml
kubectl apply -f deployment/sparkapplication.yaml
kubectl get sparkapplications -n <approved-namespace>
kubectl logs -n <approved-namespace> -f <driver-pod>
```

In production, create the Secret through External Secrets or the approved
enterprise secret process instead of applying the example directly.

## Recovery guarantees

The stream uses a stable checkpoint path. After a driver restart, Spark restores
the tracked Kafka offsets from that checkpoint. Never change or delete the
checkpoint during a normal deployment.

Iceberg commits are atomic, but the end-to-end design is treated as at-least-once
until restart/failure tests prove otherwise. The technical event identity is:

```text
(kafka_topic, kafka_partition, kafka_offset)
```

The shutdown hook stops the active query and Spark without deleting checkpoint
state. The Spark Operator restarts failed applications according to the supplied
policy. This is recovery from interruption, not a promise that pods never stop.

## Production validation checklist

1. Run `mvn clean test` and `mvn clean package`.
2. Confirm EKS resolves every advertised broker hostname.
3. Confirm driver and executors can reach every Kafka listener port.
4. Validate SASL/SSL or Kerberos without logging secrets.
5. Consume a controlled topic and verify offsets progress.
6. Verify target and DLQ data in Iceberg.
7. Restart the driver during a micro-batch and verify checkpoint recovery.
8. Test malformed JSON and incompatible schema changes.
9. Confirm S3, Glue, and KMS least-privilege permissions.
10. Monitor consumer lag, input rate, batch duration, DLQ volume, failed
    commits, driver restarts, and checkpoint access failures.
11. Approve a partition strategy before introducing partitions.
12. Schedule and observe Iceberg compaction and snapshot maintenance.

## Configuration markers

Find unresolved deployment decisions with:

```bash
rg -n 'TODO\(RECON-CONFIG\)|REPLACE_WITH|REPLACE_VIA' .
```

These markers cover the approved Kafka endpoints/topic/security, AWS region,
Glue database, Iceberg table names, S3 warehouse/checkpoint, EKS namespace,
service account, IAM role, ECR image, truststore, secret injection, query name,
and partition strategy.

## Troubleshooting

- No schema sample: publish valid JSON before `sampleTimeoutSeconds` expires, or
  switch to `schema-resource` mode.
- Bootstrap works but consumption fails: verify every hostname returned through
  Kafka `advertised.listeners`, not only the bootstrap hosts.
- MinIO access denied: source `.env` and confirm the local bucket exists.
- Duplicate rows after failure: reconcile by topic, partition, and offset.
- New field missing: restart with a controlled sample or updated schema resource;
  schema is intentionally frozen within a running query.
- Incompatible type: correct the producer contract or perform an approved table
  migration. The application does not silently rewrite existing types.

