# Build validation

Validated on 2026-08-12 with OpenJDK 17.0.19.

## Passed

- Scala production compilation: 13 source files
- Scala test compilation: 3 source files
- ScalaTest: 9 passed, 0 failed
- Maven package phase
- Executable JAR manifest and main class
- Runtime dependency assembly
- Shell syntax for all scripts
- XML parsing for `pom.xml`
- YAML parsing for Docker Compose and EKS manifests

Generated build outputs:

```text
target/ReconStreamPipeline.jar
target/dependency/
```

## Not executed in this workspace

- Docker Compose startup
- Kafka/Redpanda integration
- MinIO Iceberg commit/read integration
- Docker image build
- EKS deployment

Docker, Spark CLI tools, an EKS cluster, and access to the on-premises Kafka
network were not available in the validation workspace. Use the documented
local integration sequence before promoting the image to EKS.

