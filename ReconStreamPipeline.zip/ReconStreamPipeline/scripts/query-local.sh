#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

[[ -f .env ]] || { echo "Run ./scripts/start-local.sh first" >&2; exit 1; }
set -a
source .env
set +a
runtime_jars=$(find target/dependency -type f -name '*.jar' -print | paste -sd, -)

spark-sql \
  --master 'local[*]' \
  --jars "$runtime_jars" \
  --conf spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions \
  --conf spark.sql.catalog.local_catalog=org.apache.iceberg.spark.SparkCatalog \
  --conf spark.sql.catalog.local_catalog.type=hadoop \
  --conf spark.sql.catalog.local_catalog.warehouse=s3://warehouse/iceberg \
  --conf spark.sql.catalog.local_catalog.io-impl=org.apache.iceberg.aws.s3.S3FileIO \
  --conf spark.sql.catalog.local_catalog.client.region=us-east-1 \
  --conf spark.sql.catalog.local_catalog.s3.endpoint=http://localhost:9000 \
  --conf spark.sql.catalog.local_catalog.s3.path-style-access=true \
  -e "SELECT * FROM local_catalog.recon.lifecycle_events ORDER BY kafka_partition, kafka_offset;
      SELECT * FROM local_catalog.recon.lifecycle_events_dlq ORDER BY kafka_partition, kafka_offset;
      SELECT * FROM local_catalog.recon.lifecycle_events.snapshots;
      SELECT * FROM local_catalog.recon.lifecycle_events.files;"

