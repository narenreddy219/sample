#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

java_version=$(java -version 2>&1 | head -1)
if [[ "$java_version" != *'version "17'* ]]; then
  echo "Java 17 is required; found: $java_version" >&2
  exit 1
fi
command -v mvn >/dev/null || { echo "Maven is required" >&2; exit 1; }

mvn clean test
mvn package -DskipTests
echo "Built target/ReconStreamPipeline.jar"

