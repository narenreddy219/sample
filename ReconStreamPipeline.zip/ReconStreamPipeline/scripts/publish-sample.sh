#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

# Local development data only. Different attributes exercise schema inference.
printf '%s\n' \
  '{"event_type":"POSITION_OPENED","event_timestamp":"2026-08-12T14:30:00Z","account":{"region":"NA","book":"TEST"},"amount":125.50}' \
  '{"event_type":"POSITION_CLOSED","event_timestamp":"2026-08-12T14:31:00Z","account":{"region":"EU","book":"DEMO"},"amount":75.25,"currency":"USD"}' \
  '{"event_type":' |
docker compose -f docker-compose.local.yml exec -T redpanda \
  rpk topic produce lifecycle-events

