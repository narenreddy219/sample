#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

for command_name in java mvn docker spark-submit; do
  command -v "$command_name" >/dev/null || { echo "$command_name is required" >&2; exit 1; }
done
java -version 2>&1 | head -1 | grep -q 'version "17' || { echo "Java 17 is required" >&2; exit 1; }

if [[ ! -f .env ]]; then
  cp .env.local.example .env
  echo "Created .env from local-only example values"
fi
set -a
source .env
set +a

docker compose --env-file .env -f docker-compose.local.yml up -d
until docker compose -f docker-compose.local.yml exec -T redpanda rpk cluster health >/dev/null 2>&1; do
  echo "Waiting for local Kafka..."
  sleep 2
done
docker compose -f docker-compose.local.yml exec -T redpanda \
  rpk topic create lifecycle-events --if-not-exists

./scripts/build.sh
runtime_jars=$(find target/dependency -type f -name '*.jar' -print | paste -sd, -)
if [[ -z "$runtime_jars" ]]; then
  echo "No runtime dependency JARs were produced" >&2
  exit 1
fi

echo "Starting the stream. Run ./scripts/publish-sample.sh from another terminal within 60 seconds."
spark-submit \
  --master 'local[*]' \
  --jars "$runtime_jars" \
  --class com.citi.olympus.gru.liftandshiftpipeline.liftandshiftpipelineApp \
  target/ReconStreamPipeline.jar

