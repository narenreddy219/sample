#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose -f docker-compose.local.yml down
echo "Local containers stopped; MinIO data volume was preserved."

