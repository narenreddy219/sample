package com.citi.olympus.gru.liftandshiftpipeline.iceberg

import com.citi.olympus.gru.liftandshiftpipeline.config.IcebergConfig
import com.citi.olympus.gru.liftandshiftpipeline.schema.SchemaCompatibilityValidator
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import java.sql.Timestamp
import java.time.Instant

object IcebergTableManager {
  private val logger = LoggerFactory.getLogger(getClass)
  private val Identifier = "^[A-Za-z_][A-Za-z0-9_]*$".r

  def ensureTargetTable(spark: SparkSession, frame: DataFrame, config: IcebergConfig): Unit =
    ensureTable(spark, frame, config.fullyQualifiedTableName, config)

  def ensureDeadLetterTable(spark: SparkSession, frame: DataFrame, config: IcebergConfig): Unit =
    ensureTable(spark, frame, config.fullyQualifiedDeadLetterTableName, config)

  private def ensureTable(
      spark: SparkSession,
      frame: DataFrame,
      tableName: String,
      config: IcebergConfig
  ): Unit = {
    spark.sql(s"CREATE NAMESPACE IF NOT EXISTS ${quotedNamespace(config)}")
    if (!tableExists(spark, tableName)) {
      // TODO(RECON-CONFIG): Confirm the approved Iceberg partition strategy.
      frame.limit(0).writeTo(tableName)
        .tableProperty("format-version", "2")
        .tableProperty("write.parquet.compression-codec", "zstd")
        .create()
      logger.info("Created unpartitioned Iceberg v2 table {}", tableName)
    } else {
      evolveTable(spark, frame, tableName)
    }
  }

  private def evolveTable(spark: SparkSession, incoming: DataFrame, tableName: String): Unit = {
    val existingSchema = spark.table(tableName).schema
    val plan = SchemaCompatibilityValidator.compare(existingSchema, incoming.schema)
    if (!plan.isCompatible) {
      throw new IllegalStateException(
        s"Incompatible schema for $tableName: ${plan.incompatibilities.mkString("; ")}")
    }
    plan.additions.foreach { field =>
      val column = quoteIdentifier(field.name)
      spark.sql(s"ALTER TABLE $tableName ADD COLUMN $column ${field.dataType.sql}")
      logger.info("Added nullable Iceberg column {}.{} with type {}", tableName, field.name, field.dataType.sql)
    }
  }

  def runMaintenanceIfDue(
      spark: SparkSession,
      batchId: Long,
      config: IcebergConfig
  ): Unit = {
    val maintenance = config.maintenance
    if (!maintenance.enabled || batchId <= 0 || batchId % maintenance.runEveryNBatches != 0) return

    val olderThan = Timestamp.from(Instant.now().minusSeconds(maintenance.expireSnapshotsOlderThanHours.toLong * 3600L))
    try {
      spark.sql(
        s"CALL ${quoteIdentifier(config.catalogName)}.system.expire_snapshots(" +
          s"table => '${config.schemaName}.${config.tableName}', " +
          s"older_than => TIMESTAMP '${olderThan.toLocalDateTime}', " +
          s"retain_last => ${maintenance.retainLastSnapshots})"
      )
      logger.info("Completed Iceberg snapshot expiration for {}", config.fullyQualifiedTableName)
    } catch {
      case error: Exception =>
        logger.warn("Iceberg maintenance failed without invalidating committed stream data", error)
    }
  }

  private def tableExists(spark: SparkSession, tableName: String): Boolean =
    try {
      spark.table(tableName).schema
      true
    } catch {
      case _: org.apache.spark.sql.AnalysisException => false
    }

  private def quotedNamespace(config: IcebergConfig): String =
    s"${quoteIdentifier(config.catalogName)}.${quoteIdentifier(config.schemaName)}"

  private def quoteIdentifier(value: String): String = value match {
    case Identifier() => s"`$value`"
    case _ => throw new IllegalArgumentException(s"Invalid SQL identifier: $value")
  }
}

