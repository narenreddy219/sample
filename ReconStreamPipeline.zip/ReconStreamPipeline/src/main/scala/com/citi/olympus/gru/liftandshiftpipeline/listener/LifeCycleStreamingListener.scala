package com.citi.olympus.gru.liftandshiftpipeline.listener

import org.apache.spark.sql.streaming.StreamingQueryListener
import org.slf4j.LoggerFactory

final class LifeCycleStreamingListener extends StreamingQueryListener {
  private val logger = LoggerFactory.getLogger(getClass)

  override def onQueryStarted(event: StreamingQueryListener.QueryStartedEvent): Unit =
    logger.info("Streaming query started: id={}, runId={}, name={}",
      event.id, event.runId, event.name)

  override def onQueryProgress(event: StreamingQueryListener.QueryProgressEvent): Unit = {
    val progress = event.progress
    logger.info(
      "Streaming progress: id={}, runId={}, batchId={}, inputRows={}, inputRate={}, processedRate={}, durationMs={}",
      progress.id,
      progress.runId,
      Long.box(progress.batchId),
      Long.box(progress.numInputRows),
      Double.box(progress.inputRowsPerSecond),
      Double.box(progress.processedRowsPerSecond),
      progress.durationMs.toString
    )
  }

  override def onQueryTerminated(event: StreamingQueryListener.QueryTerminatedEvent): Unit =
    event.exception match {
      case Some(error) => logger.error("Streaming query terminated: id={}, runId={}, error={}",
        event.id, event.runId, error)
      case None => logger.info(s"Streaming query stopped: id=${event.id}, runId=${event.runId}")
    }

  override def onQueryIdle(event: StreamingQueryListener.QueryIdleEvent): Unit =
    logger.debug(s"Streaming query idle: id=${event.id}, runId=${event.runId}")
}
