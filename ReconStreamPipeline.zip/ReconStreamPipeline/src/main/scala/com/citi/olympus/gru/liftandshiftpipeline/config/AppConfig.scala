package com.citi.olympus.gru.liftandshiftpipeline.config

final case class KafkaConfig(
    bootstrapServers: String,
    topic: String,
    startingOffsets: String,
    maxOffsetsPerTrigger: Option[Long],
    failOnDataLoss: Boolean,
    healthCheckTimeoutSeconds: Int,
    sslOptions: Map[String, String]
)

final case class StorageConfig(
    storageType: String,
    endpoint: Option[String],
    region: String,
    pathStyleAccess: Boolean
)

final case class IcebergMaintenanceConfig(
    enabled: Boolean,
    runEveryNBatches: Int,
    expireSnapshotsOlderThanHours: Int,
    retainLastSnapshots: Int
)

final case class IcebergConfig(
    catalogName: String,
    catalogType: String,
    schemaName: String,
    tableName: String,
    deadLetterTableName: String,
    warehousePath: String,
    maintenance: IcebergMaintenanceConfig
) {
  private val Identifier = "^[A-Za-z_][A-Za-z0-9_]*$".r

  private def validated(value: String, label: String): String = value match {
    case Identifier() => value
    case _ => throw new IllegalArgumentException(s"Invalid $label identifier: $value")
  }

  def namespace: String =
    s"${validated(catalogName, "catalog")}.${validated(schemaName, "schema")}" 

  def fullyQualifiedTableName: String =
    s"$namespace.${validated(tableName, "table")}" 

  def fullyQualifiedDeadLetterTableName: String =
    s"$namespace.${validated(deadLetterTableName, "dead-letter table")}" 
}

final case class CheckpointConfig(
    checkpointPath: String,
    minBatchesToRetain: Int
)

final case class StreamingConfig(
    triggerInterval: String,
    watchWindowMinutes: Int,
    queryName: String
)

final case class SchemaInferenceConfig(
    mode: String,
    sampleMaximumMessages: Int,
    sampleTimeoutSeconds: Int,
    optionalSchemaResource: Option[String],
    flattenNestedStructs: Boolean,
    flattenDelimiter: String
)

final case class AppConfig(
    env: String,
    pipelineName: String,
    pipelineId: String,
    kafka: KafkaConfig,
    storage: StorageConfig,
    iceberg: IcebergConfig,
    checkpoint: CheckpointConfig,
    streaming: StreamingConfig,
    schemaInference: SchemaInferenceConfig
)

