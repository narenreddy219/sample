package com.citi.olympus.gru.liftandshiftpipeline.parser

import com.citi.olympus.gru.liftandshiftpipeline.config.SchemaInferenceConfig
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StructField, StructType}
import org.apache.spark.sql.{Column, DataFrame}

final case class ParsedLifeCycleStream(dataFrame: DataFrame, payloadColumns: Seq[String])

object LifeCycleEventParser {
  private val CorruptRecordColumn = "_corrupt_record"

  def parse(
      rawKafka: DataFrame,
      payloadSchema: StructType,
      config: SchemaInferenceConfig
  ): ParsedLifeCycleStream = {
    require(!payloadSchema.fieldNames.contains(CorruptRecordColumn),
      s"Payload schema must not contain reserved field $CorruptRecordColumn")

    val parsingSchema = payloadSchema.add(CorruptRecordColumn, "string", nullable = true)
    val decoded = rawKafka.select(
      col("key").cast("string").as("kafka_key"),
      col("value").cast("string").as("raw_payload"),
      col("topic").as("kafka_topic"),
      col("partition").as("kafka_partition"),
      col("offset").as("kafka_offset"),
      col("timestamp").as("kafka_timestamp"),
      from_json(
        col("value").cast("string"),
        parsingSchema,
        Map("mode" -> "PERMISSIVE", "columnNameOfCorruptRecord" -> CorruptRecordColumn)
      ).as("payload")
    )

    val payloadSelections = if (config.flattenNestedStructs) {
      flatten(payloadSchema, Seq("payload"), Seq.empty, config.flattenDelimiter)
    } else {
      payloadSchema.fields.map { field =>
        pathColumn(Seq("payload", field.name)).as(field.name) -> field.name
      }.toSeq
    }
    val payloadNames = payloadSelections.map(_._2)
    val duplicates = payloadNames.groupBy(identity).collect { case (name, values) if values.size > 1 => name }.toSeq
    require(duplicates.isEmpty, s"Flattened payload column collision: ${duplicates.sorted.mkString(", ")}")

    val invalid = col("payload").isNull
      .or(pathColumn(Seq("payload", CorruptRecordColumn)).isNotNull)
      .or(length(trim(col("raw_payload"))) === 0)

    val result = decoded.select(
      (payloadSelections.map(_._1) ++ Seq(
        col("raw_payload"),
        col("kafka_key"),
        col("kafka_topic"),
        col("kafka_partition"),
        col("kafka_offset"),
        col("kafka_timestamp"),
        current_timestamp().as("ingestion_timestamp"),
        not(invalid).as("is_valid"),
        when(invalid, lit("MALFORMED_JSON")).otherwise(lit(null).cast("string")).as("error_type"),
        when(invalid, lit("Payload is empty or is not valid JSON"))
          .otherwise(lit(null).cast("string")).as("error_detail")
      )): _*
    )
    ParsedLifeCycleStream(result, payloadNames)
  }

  private def flatten(
      schema: StructType,
      sourcePath: Seq[String],
      outputPath: Seq[String],
      delimiter: String
  ): Seq[(Column, String)] = {
    schema.fields.toSeq.flatMap { field =>
      val nextSource = sourcePath :+ field.name
      val nextOutput = outputPath :+ field.name
      field.dataType match {
        case nested: StructType => flatten(nested, nextSource, nextOutput, delimiter)
        case _: DataType =>
          val outputName = nextOutput.mkString(delimiter)
          Seq(pathColumn(nextSource).as(outputName) -> outputName)
      }
    }
  }

  private def pathColumn(path: Seq[String]): Column =
    col(path.map(part => s"`${part.replace("`", "``")}`").mkString("."))
}
