package com.citi.olympus.gru.liftandshiftpipeline

import com.citi.olympus.gru.liftandshiftpipeline.config.{ConfigLoader, SparkSessionFactory}
import com.citi.olympus.gru.liftandshiftpipeline.iceberg.IcebergStreamWriter
import com.citi.olympus.gru.liftandshiftpipeline.kafka.{kafkaHealthCheck, kafkaReader}
import com.citi.olympus.gru.liftandshiftpipeline.listener.LifeCycleStreamingListener
import com.citi.olympus.gru.liftandshiftpipeline.parser.LifeCycleEventParser
import com.citi.olympus.gru.liftandshiftpipeline.schema.PayloadSchemaInferencer
import org.apache.spark.sql.streaming.StreamingQuery
import org.slf4j.LoggerFactory

import java.util.concurrent.atomic.AtomicBoolean

object LifecycleEventsApp {
  private val logger = LoggerFactory.getLogger(getClass)

  def run(): Unit = {
    val config = ConfigLoader.load()
    val spark = SparkSessionFactory.create(config)
    spark.sparkContext.setLogLevel(sys.env.getOrElse("SPARK_LOG_LEVEL", "WARN"))
    spark.streams.addListener(new LifeCycleStreamingListener)

    var query: Option[StreamingQuery] = None
    val closing = new AtomicBoolean(false)
    sys.addShutdownHook {
      if (closing.compareAndSet(false, true)) {
        logger.info("Graceful shutdown requested")
        query.filter(_.isActive).foreach(_.stop())
        spark.stop()
      }
    }

    try {
      logger.info("Starting pipeline={}, pipelineId={}, environment={}",
        config.pipelineName, config.pipelineId, config.env)
      kafkaHealthCheck.verify(config.kafka)
      val payloadSchema = PayloadSchemaInferencer.infer(spark, config)
      val raw = kafkaReader.readStream(spark, config.kafka)
      val parsed = LifeCycleEventParser.parse(raw, payloadSchema, config.schemaInference)
      val activeQuery = IcebergStreamWriter.start(spark, parsed, config)
      query = Some(activeQuery)
      activeQuery.awaitTermination()
    } finally {
      if (closing.compareAndSet(false, true)) {
        query.filter(_.isActive).foreach(_.stop())
        spark.stop()
      }
    }
  }
}

