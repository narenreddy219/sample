package com.citi.olympus.gru.liftandshiftpipeline.schema

import com.citi.olympus.gru.liftandshiftpipeline.config.AppConfig
import com.citi.olympus.gru.liftandshiftpipeline.kafka.KafkaOptionAdapter
import org.apache.kafka.clients.consumer.{ConsumerConfig, KafkaConsumer}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{DataType, StructType}
import org.slf4j.LoggerFactory

import java.time.{Duration, Instant}
import java.util.{Collections, Properties, UUID}
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer
import scala.io.Source

object PayloadSchemaInferencer {
  private val logger = LoggerFactory.getLogger(getClass)

  def infer(spark: SparkSession, config: AppConfig): StructType = {
    val schema = config.schemaInference.mode match {
      case "kafka-sample" => inferFromKafka(spark, config)
      case "schema-resource" => loadResource(config.schemaInference.optionalSchemaResource.get)
      case unsupported => throw new IllegalArgumentException(s"Unsupported schema inference mode: $unsupported")
    }
    if (schema.isEmpty) throw new IllegalStateException("Payload schema contains no fields")
    logger.info("Frozen payload schema for this run: {}", schema.simpleString)
    schema
  }

  private def inferFromKafka(spark: SparkSession, config: AppConfig): StructType = {
    val kafka = config.kafka
    val settings = config.schemaInference
    val properties = new Properties()
    properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.bootstrapServers)
    properties.put(ConsumerConfig.GROUP_ID_CONFIG, s"${config.pipelineId}-schema-${UUID.randomUUID()}")
    properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")
    properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, kafka.startingOffsets)
    properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, classOf[StringDeserializer].getName)
    properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, classOf[StringDeserializer].getName)
    KafkaOptionAdapter.forClient(kafka.sslOptions).foreach { case (key, value) => properties.put(key, value) }

    val consumer = new KafkaConsumer[String, String](properties)
    val samples = ArrayBuffer.empty[String]
    val deadline = Instant.now().plusSeconds(settings.sampleTimeoutSeconds.toLong)
    try {
      consumer.subscribe(Collections.singletonList(kafka.topic))
      while (samples.size < settings.sampleMaximumMessages && Instant.now().isBefore(deadline)) {
        consumer.poll(Duration.ofMillis(500)).asScala.iterator
          .map(_.value())
          .filter(value => value != null && value.trim.nonEmpty)
          .take(settings.sampleMaximumMessages - samples.size)
          .foreach(samples += _)
      }
    } finally {
      consumer.close(Duration.ofSeconds(5))
    }

    if (samples.isEmpty) {
      throw new IllegalStateException(
        s"No Kafka payloads were available for schema inference within ${settings.sampleTimeoutSeconds} seconds")
    }

    import spark.implicits._
    val inferred = spark.read
      .option("mode", "DROPMALFORMED")
      .json(spark.createDataset(samples))
      .schema
    StructType(inferred.fields.filterNot(_.name == "_corrupt_record"))
  }

  private def loadResource(resource: String): StructType = {
    val stream = Option(getClass.getClassLoader.getResourceAsStream(resource))
      .getOrElse(throw new IllegalArgumentException(s"Schema resource not found: $resource"))
    val source = Source.fromInputStream(stream, "UTF-8")
    try DataType.fromJson(source.mkString).asInstanceOf[StructType]
    finally source.close()
  }
}
