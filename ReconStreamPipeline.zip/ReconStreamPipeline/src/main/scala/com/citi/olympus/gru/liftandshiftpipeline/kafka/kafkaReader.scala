package com.citi.olympus.gru.liftandshiftpipeline.kafka

import com.citi.olympus.gru.liftandshiftpipeline.config.KafkaConfig
import org.apache.spark.sql.{DataFrame, SparkSession}

object kafkaReader {
  def readStream(spark: SparkSession, config: KafkaConfig): DataFrame = {
    val baseOptions = Map(
      "kafka.bootstrap.servers" -> config.bootstrapServers,
      "subscribe" -> config.topic,
      "startingOffsets" -> config.startingOffsets,
      "failOnDataLoss" -> config.failOnDataLoss.toString
    ) ++ KafkaOptionAdapter.forSpark(config.sslOptions) ++
      config.maxOffsetsPerTrigger.map(value => "maxOffsetsPerTrigger" -> value.toString).toMap

    spark.readStream
      .format("kafka")
      .options(baseOptions)
      .load()
  }
}

private[liftandshiftpipeline] object KafkaOptionAdapter {
  private val SparkPrefix = "kafka."

  def forSpark(options: Map[String, String]): Map[String, String] =
    options.map { case (key, value) =>
      if (key.startsWith(SparkPrefix)) key -> value else s"$SparkPrefix$key" -> value
    }

  def forClient(options: Map[String, String]): Map[String, String] =
    options.map { case (key, value) => key.stripPrefix(SparkPrefix) -> value }
}

