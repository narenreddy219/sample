package com.citi.olympus.gru.liftandshiftpipeline.config

import org.apache.spark.sql.SparkSession

object SparkSessionFactory {
  def create(config: AppConfig): SparkSession = {
    val catalog = config.iceberg.catalogName
    val base = SparkSession.builder()
      .appName(config.pipelineName)
      .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
      .config(s"spark.sql.catalog.$catalog", "org.apache.iceberg.spark.SparkCatalog")
      .config(s"spark.sql.catalog.$catalog.warehouse", config.iceberg.warehousePath)
      .config(s"spark.sql.catalog.$catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
      .config(s"spark.sql.catalog.$catalog.client.region", config.storage.region)
      .config("spark.sql.streaming.minBatchesToRetain", config.checkpoint.minBatchesToRetain)
      .config("spark.sql.session.timeZone", "UTC")

    val configured = config.storage.storageType match {
      case "minio" =>
        base
          .config(s"spark.sql.catalog.$catalog.type", "hadoop")
          .config(s"spark.sql.catalog.$catalog.s3.endpoint", config.storage.endpoint.get)
          .config(s"spark.sql.catalog.$catalog.s3.path-style-access", config.storage.pathStyleAccess)
      case "s3" =>
        base
          .config(s"spark.sql.catalog.$catalog.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")
      case unsupported => throw new IllegalArgumentException(s"Unsupported storage type: $unsupported")
    }
    configured.getOrCreate()
  }
}

