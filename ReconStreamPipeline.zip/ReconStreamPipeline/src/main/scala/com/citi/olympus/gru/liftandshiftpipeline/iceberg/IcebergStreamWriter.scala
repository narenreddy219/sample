package com.citi.olympus.gru.liftandshiftpipeline.iceberg

import com.citi.olympus.gru.liftandshiftpipeline.config.AppConfig
import com.citi.olympus.gru.liftandshiftpipeline.parser.ParsedLifeCycleStream
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.streaming.{StreamingQuery, Trigger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object IcebergStreamWriter {
  private val logger = LoggerFactory.getLogger(getClass)
  private val KafkaMetadata = Seq(
    "kafka_key", "kafka_topic", "kafka_partition", "kafka_offset",
    "kafka_timestamp", "ingestion_timestamp"
  )

  def start(
      spark: SparkSession,
      parsed: ParsedLifeCycleStream,
      config: AppConfig
  ): StreamingQuery = {
    parsed.dataFrame.writeStream
      .foreachBatch { (batch: DataFrame, batchId: Long) =>
        writeBatch(spark, batch, batchId, parsed.payloadColumns, config)
      }
      .option("checkpointLocation", config.checkpoint.checkpointPath)
      .queryName(config.streaming.queryName)
      .trigger(Trigger.ProcessingTime(config.streaming.triggerInterval))
      .start()
  }

  private[liftandshiftpipeline] def writeBatch(
      spark: SparkSession,
      batch: DataFrame,
      batchId: Long,
      payloadColumns: Seq[String],
      config: AppConfig
  ): Unit = {
    if (batch.take(1).isEmpty) {
      logger.info("Skipping empty micro-batch {}", Long.box(batchId))
      return
    }

    batch.persist()
    try {
      val valid = batch.filter(col("is_valid"))
        .select((payloadColumns ++ KafkaMetadata).map(col): _*)
      val invalid = batch.filter(!col("is_valid"))
        .select(
          col("raw_payload"), col("error_type"), col("error_detail"),
          col("kafka_key"), col("kafka_topic"), col("kafka_partition"),
          col("kafka_offset"), col("kafka_timestamp"), col("ingestion_timestamp"),
          lit(batchId).as("spark_batch_id")
        )

      val validCount = valid.count()
      val invalidCount = invalid.count()
      logger.info("Processing batch {}: valid={}, invalid={}",
        Long.box(batchId), Long.box(validCount), Long.box(invalidCount))

      if (validCount > 0) {
        IcebergTableManager.ensureTargetTable(spark, valid, config.iceberg)
        valid.writeTo(config.iceberg.fullyQualifiedTableName).append()
      }
      if (invalidCount > 0) {
        IcebergTableManager.ensureDeadLetterTable(spark, invalid, config.iceberg)
        invalid.writeTo(config.iceberg.fullyQualifiedDeadLetterTableName).append()
      }
      IcebergTableManager.runMaintenanceIfDue(spark, batchId, config.iceberg)
      logger.info("Completed Iceberg commits for batch {}", Long.box(batchId))
    } finally {
      batch.unpersist()
    }
  }
}

