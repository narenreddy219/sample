package com.citi.olympus.gru.liftandshiftpipeline.kafka

import com.citi.olympus.gru.liftandshiftpipeline.config.KafkaConfig
import org.apache.kafka.clients.admin.{AdminClient, AdminClientConfig}
import org.slf4j.LoggerFactory

import java.time.Duration
import java.util.Properties
import java.util.concurrent.TimeUnit
import scala.collection.JavaConverters._

object kafkaHealthCheck {
  private val logger = LoggerFactory.getLogger(getClass)

  def verify(config: KafkaConfig): Unit = {
    val properties = new Properties()
    properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, config.bootstrapServers)
    properties.put(AdminClientConfig.REQUEST_TIMEOUT_MS_CONFIG, (config.healthCheckTimeoutSeconds * 1000).toString)
    KafkaOptionAdapter.forClient(config.sslOptions).foreach { case (key, value) => properties.put(key, value) }

    val admin = AdminClient.create(properties)
    try {
      val timeout = config.healthCheckTimeoutSeconds.toLong
      val nodes = admin.describeCluster().nodes().get(timeout, TimeUnit.SECONDS)
      if (nodes.isEmpty) throw new IllegalStateException("Kafka health check returned no brokers")

      val topics = admin.listTopics().names().get(timeout, TimeUnit.SECONDS).asScala
      if (!topics.contains(config.topic)) {
        throw new IllegalStateException(s"Configured Kafka topic '${config.topic}' does not exist")
      }
      logger.info(s"Kafka health check succeeded: brokers=${nodes.size()}, topic=${config.topic}")
    } finally {
      admin.close(Duration.ofSeconds(5))
    }
  }
}
