package com.citi.olympus.gru.liftandshiftpipeline.config

import com.typesafe.config.{Config, ConfigException, ConfigFactory}

import scala.collection.JavaConverters._

object ConfigLoader {
  private val SupportedEnvironments = Set("local", "dev", "uat")

  def load(environment: String = sys.env.getOrElse("APP_ENV", "local")): AppConfig = {
    val env = environment.trim.toLowerCase
    require(SupportedEnvironments.contains(env),
      s"Unsupported APP_ENV '$env'. Supported values: ${SupportedEnvironments.toSeq.sorted.mkString(", ")}")

    try {
      val global = ConfigFactory.parseResources("config/global.conf")
      val selected = ConfigFactory.parseResources(s"config/source_connector_$env.conf")
      val root = selected.withFallback(global).resolve().getConfig("recon")
      val result = toAppConfig(root)
      validate(result)
      result
    } catch {
      case error: ConfigException =>
        throw new IllegalArgumentException(
          s"Unable to load configuration for APP_ENV=$env: ${error.getMessage}", error)
    }
  }

  private def toAppConfig(config: Config): AppConfig = {
    val kafka = config.getConfig("kafka")
    val storage = config.getConfig("storage")
    val iceberg = config.getConfig("iceberg")
    val maintenance = iceberg.getConfig("maintenance")
    val checkpoint = config.getConfig("checkpoint")
    val streaming = config.getConfig("streaming")
    val schema = config.getConfig("schemaInference")

    AppConfig(
      env = required(config, "env"),
      pipelineName = required(config, "pipelineName"),
      pipelineId = required(config, "pipelineId"),
      kafka = KafkaConfig(
        bootstrapServers = required(kafka, "bootstrapServers"),
        topic = required(kafka, "topic"),
        startingOffsets = required(kafka, "startingOffsets"),
        maxOffsetsPerTrigger = optionalLong(kafka, "maxOffsetsPerTrigger"),
        failOnDataLoss = kafka.getBoolean("failOnDataLoss"),
        healthCheckTimeoutSeconds = kafka.getInt("healthCheckTimeoutSeconds"),
        sslOptions = stringMap(kafka, "sslOptions")
      ),
      storage = StorageConfig(
        storageType = required(storage, "storageType").toLowerCase,
        endpoint = optionalString(storage, "endpoint"),
        region = required(storage, "region"),
        pathStyleAccess = storage.getBoolean("pathStyleAccess")
      ),
      iceberg = IcebergConfig(
        catalogName = required(iceberg, "catalogName"),
        catalogType = required(iceberg, "catalogType").toLowerCase,
        schemaName = required(iceberg, "schemaName"),
        tableName = required(iceberg, "tableName"),
        deadLetterTableName = required(iceberg, "deadLetterTableName"),
        warehousePath = required(iceberg, "warehousePath"),
        maintenance = IcebergMaintenanceConfig(
          enabled = maintenance.getBoolean("enabled"),
          runEveryNBatches = maintenance.getInt("runEveryNBatches"),
          expireSnapshotsOlderThanHours = maintenance.getInt("expireSnapshotsOlderThanHours"),
          retainLastSnapshots = maintenance.getInt("retainLastSnapshots")
        )
      ),
      checkpoint = CheckpointConfig(
        checkpointPath = required(checkpoint, "checkpointPath"),
        minBatchesToRetain = checkpoint.getInt("minBatchesToRetain")
      ),
      streaming = StreamingConfig(
        triggerInterval = required(streaming, "triggerInterval"),
        watchWindowMinutes = streaming.getInt("watchWindowMinutes"),
        queryName = required(streaming, "queryName")
      ),
      schemaInference = SchemaInferenceConfig(
        mode = required(schema, "mode").toLowerCase,
        sampleMaximumMessages = schema.getInt("sampleMaximumMessages"),
        sampleTimeoutSeconds = schema.getInt("sampleTimeoutSeconds"),
        optionalSchemaResource = optionalString(schema, "optionalSchemaResource"),
        flattenNestedStructs = schema.getBoolean("flattenNestedStructs"),
        flattenDelimiter = required(schema, "flattenDelimiter")
      )
    )
  }

  private def validate(config: AppConfig): Unit = {
    require(config.kafka.bootstrapServers.split(',').forall(_.trim.contains(":")),
      "Every Kafka bootstrap server must use host:port format")
    require(Set("earliest", "latest").contains(config.kafka.startingOffsets),
      "kafka.startingOffsets must be earliest or latest")
    require(Set("minio", "s3").contains(config.storage.storageType),
      "storage.storageType must be minio or s3")
    require(Set("hadoop", "glue").contains(config.iceberg.catalogType),
      "iceberg.catalogType must be hadoop or glue")
    require(Set("kafka-sample", "schema-resource").contains(config.schemaInference.mode),
      "schemaInference.mode must be kafka-sample or schema-resource")
    require(config.checkpoint.minBatchesToRetain > 0, "minBatchesToRetain must be positive")
    require(config.schemaInference.sampleMaximumMessages > 0, "sampleMaximumMessages must be positive")
    require(config.schemaInference.sampleTimeoutSeconds > 0, "sampleTimeoutSeconds must be positive")
    require(config.kafka.healthCheckTimeoutSeconds > 0, "healthCheckTimeoutSeconds must be positive")
    if (config.storage.storageType == "minio") {
      require(config.storage.endpoint.exists(_.nonEmpty), "MinIO storage requires storage.endpoint")
      require(config.iceberg.catalogType == "hadoop", "Local MinIO requires the Hadoop catalog")
    }
    if (config.storage.storageType == "s3") {
      require(config.storage.endpoint.isEmpty, "Amazon S3 configuration must not define a MinIO endpoint")
      require(config.iceberg.catalogType == "glue", "Amazon S3 production configuration requires Glue catalog")
      require(config.checkpoint.checkpointPath.startsWith("s3://"), "EKS checkpointPath must use s3://")
    }
    if (config.schemaInference.mode == "schema-resource") {
      require(config.schemaInference.optionalSchemaResource.exists(_.nonEmpty),
        "schema-resource mode requires optionalSchemaResource")
    }
    config.iceberg.fullyQualifiedTableName
    config.iceberg.fullyQualifiedDeadLetterTableName
  }

  private def required(config: Config, path: String): String = {
    val value = config.getString(path).trim
    require(value.nonEmpty, s"Configuration '$path' must not be empty")
    value
  }

  private def optionalString(config: Config, path: String): Option[String] =
    if (config.hasPath(path)) Option(config.getString(path)).map(_.trim).filter(_.nonEmpty) else None

  private def optionalLong(config: Config, path: String): Option[Long] =
    if (config.hasPath(path)) Some(config.getLong(path)) else None

  private def stringMap(config: Config, path: String): Map[String, String] = {
    if (!config.hasPath(path)) Map.empty
    else config.getConfig(path).entrySet().asScala.map { entry =>
      entry.getKey -> String.valueOf(entry.getValue.unwrapped())
    }.toMap
  }
}

