package com.citi.olympus.gru.liftandshiftpipeline

object liftandshiftpipelineApp {
  def main(args: Array[String]): Unit = LifecycleEventsApp.run()
}

