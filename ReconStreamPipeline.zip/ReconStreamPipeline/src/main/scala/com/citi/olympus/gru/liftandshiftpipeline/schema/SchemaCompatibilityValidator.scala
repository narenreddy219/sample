package com.citi.olympus.gru.liftandshiftpipeline.schema

import org.apache.spark.sql.types._

final case class SchemaEvolutionPlan(
    additions: Seq[StructField],
    incompatibilities: Seq[String]
) {
  def isCompatible: Boolean = incompatibilities.isEmpty
}

object SchemaCompatibilityValidator {
  def compare(existing: StructType, incoming: StructType): SchemaEvolutionPlan = {
    val existingByName = existing.fields.map(field => field.name -> field).toMap
    val additions = incoming.fields.filterNot(field => existingByName.contains(field.name)).toSeq
    val conflicts = incoming.fields.flatMap { next =>
      existingByName.get(next.name).flatMap { current =>
        if (canStore(current.dataType, next.dataType)) None
        else Some(s"Column '${next.name}' is ${current.dataType.sql} but incoming data is ${next.dataType.sql}")
      }
    }.toSeq
    SchemaEvolutionPlan(additions, conflicts)
  }

  private def canStore(existing: DataType, incoming: DataType): Boolean = (existing, incoming) match {
    case (left, right) if left == right => true
    case (LongType, IntegerType | ShortType | ByteType) => true
    case (IntegerType, ShortType | ByteType) => true
    case (ShortType, ByteType) => true
    case (DoubleType, FloatType | LongType | IntegerType | ShortType | ByteType) => true
    case (FloatType, IntegerType | ShortType | ByteType) => true
    case (existingDecimal: DecimalType, incomingDecimal: DecimalType) =>
      existingDecimal.scale >= incomingDecimal.scale &&
        (existingDecimal.precision - existingDecimal.scale) >=
          (incomingDecimal.precision - incomingDecimal.scale)
    case (StructType(existingFields), StructType(incomingFields)) =>
      compare(StructType(existingFields), StructType(incomingFields)).isCompatible
    case (ArrayType(existingElement, _), ArrayType(incomingElement, _)) =>
      canStore(existingElement, incomingElement)
    case (MapType(existingKey, existingValue, _), MapType(incomingKey, incomingValue, _)) =>
      existingKey == incomingKey && canStore(existingValue, incomingValue)
    case _ => false
  }
}
