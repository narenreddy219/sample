package com.citi.olympus.gru.liftandshiftpipeline.config

import org.scalatest.funsuite.AnyFunSuite

class ConfigLoaderSpec extends AnyFunSuite {
  test("local configuration loads MinIO and Hadoop catalog settings") {
    val config = ConfigLoader.load("local")
    assert(config.env == "local")
    assert(config.storage.storageType == "minio")
    assert(config.storage.pathStyleAccess)
    assert(config.storage.endpoint.contains("http://localhost:9000"))
    assert(config.iceberg.catalogType == "hadoop")
    assert(config.kafka.bootstrapServers == "localhost:9092")
  }

  test("unsupported environment is rejected") {
    val error = intercept[IllegalArgumentException](ConfigLoader.load("production"))
    assert(error.getMessage.contains("Unsupported APP_ENV"))
  }

  test("fully qualified names preserve the configured naming convention") {
    val config = ConfigLoader.load("local")
    assert(config.iceberg.fullyQualifiedTableName == "local_catalog.recon.lifecycle_events")
    assert(config.iceberg.fullyQualifiedDeadLetterTableName == "local_catalog.recon.lifecycle_events_dlq")
  }
}

