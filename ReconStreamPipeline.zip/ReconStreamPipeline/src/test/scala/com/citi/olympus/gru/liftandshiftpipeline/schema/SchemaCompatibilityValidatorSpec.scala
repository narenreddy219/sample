package com.citi.olympus.gru.liftandshiftpipeline.schema

import org.apache.spark.sql.types._
import org.scalatest.funsuite.AnyFunSuite

class SchemaCompatibilityValidatorSpec extends AnyFunSuite {
  test("a new nullable column is an allowed schema addition") {
    val existing = StructType(Seq(StructField("event_type", StringType, nullable = true)))
    val incoming = existing.add("currency", StringType, nullable = true)
    val plan = SchemaCompatibilityValidator.compare(existing, incoming)
    assert(plan.isCompatible)
    assert(plan.additions.map(_.name) == Seq("currency"))
  }

  test("an incompatible type change is rejected") {
    val existing = StructType(Seq(StructField("amount", LongType, nullable = true)))
    val incoming = StructType(Seq(StructField("amount", StringType, nullable = true)))
    val plan = SchemaCompatibilityValidator.compare(existing, incoming)
    assert(!plan.isCompatible)
    assert(plan.incompatibilities.exists(_.contains("amount")))
  }

  test("an existing long column can store incoming integers") {
    val existing = StructType(Seq(StructField("quantity", LongType, nullable = true)))
    val incoming = StructType(Seq(StructField("quantity", IntegerType, nullable = true)))
    assert(SchemaCompatibilityValidator.compare(existing, incoming).isCompatible)
  }
}

