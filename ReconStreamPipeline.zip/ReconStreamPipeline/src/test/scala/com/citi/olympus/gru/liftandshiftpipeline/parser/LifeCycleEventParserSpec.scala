package com.citi.olympus.gru.liftandshiftpipeline.parser

import com.citi.olympus.gru.liftandshiftpipeline.config.SchemaInferenceConfig
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SparkSession}
import org.scalatest.BeforeAndAfterAll
import org.scalatest.funsuite.AnyFunSuite

import java.nio.charset.StandardCharsets
import java.sql.Timestamp

class LifeCycleEventParserSpec extends AnyFunSuite with BeforeAndAfterAll {
  private var spark: SparkSession = _
  private val config = SchemaInferenceConfig(
    mode = "kafka-sample",
    sampleMaximumMessages = 10,
    sampleTimeoutSeconds = 5,
    optionalSchemaResource = None,
    flattenNestedStructs = true,
    flattenDelimiter = "_"
  )

  override protected def beforeAll(): Unit = {
    spark = SparkSession.builder()
      .master("local[1]")
      .appName("LifeCycleEventParserSpec")
      .config("spark.ui.enabled", "false")
      .config("spark.driver.host", "127.0.0.1")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
  }

  override protected def afterAll(): Unit = if (spark != null) spark.stop()

  test("payload attributes are flattened and Kafka metadata is preserved") {
    val schema = StructType(Seq(
      StructField("event_type", StringType, nullable = true),
      StructField("account", StructType(Seq(
        StructField("region", StringType, nullable = true)
      )), nullable = true)
    ))
    val raw = kafkaFrame("{\"event_type\":\"OPEN\",\"account\":{\"region\":\"NA\"}}")
    val parsed = LifeCycleEventParser.parse(raw, schema, config)
    val row = parsed.dataFrame.head()
    assert(parsed.payloadColumns == Seq("event_type", "account_region"))
    assert(row.getAs[String]("event_type") == "OPEN")
    assert(row.getAs[String]("account_region") == "NA")
    assert(row.getAs[String]("kafka_topic") == "lifecycle-events")
    assert(row.getAs[Long]("kafka_offset") == 7L)
    assert(row.getAs[Boolean]("is_valid"))
  }

  test("malformed JSON is marked for the dead-letter path") {
    val schema = StructType(Seq(StructField("event_type", StringType, nullable = true)))
    val parsed = LifeCycleEventParser.parse(kafkaFrame("{\"event_type\":"), schema, config)
    val row = parsed.dataFrame.head()
    assert(!row.getAs[Boolean]("is_valid"))
    assert(row.getAs[String]("error_type") == "MALFORMED_JSON")
  }

  test("flattened name collisions fail instead of overwriting a column") {
    val schema = StructType(Seq(
      StructField("account_region", StringType, nullable = true),
      StructField("account", StructType(Seq(
        StructField("region", StringType, nullable = true)
      )), nullable = true)
    ))
    val error = intercept[IllegalArgumentException] {
      LifeCycleEventParser.parse(kafkaFrame("{}"), schema, config)
    }
    assert(error.getMessage.contains("collision"))
  }

  private def kafkaFrame(payload: String) = {
    val kafkaSchema = StructType(Seq(
      StructField("key", BinaryType, nullable = true),
      StructField("value", BinaryType, nullable = false),
      StructField("topic", StringType, nullable = false),
      StructField("partition", IntegerType, nullable = false),
      StructField("offset", LongType, nullable = false),
      StructField("timestamp", TimestampType, nullable = false)
    ))
    val row = Row(
      "key-1".getBytes(StandardCharsets.UTF_8),
      payload.getBytes(StandardCharsets.UTF_8),
      "lifecycle-events",
      0,
      7L,
      Timestamp.valueOf("2026-08-12 14:30:00")
    )
    spark.createDataFrame(spark.sparkContext.parallelize(Seq(row)), kafkaSchema)
  }
}

